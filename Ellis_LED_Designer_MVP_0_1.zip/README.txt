ELLIS LED DESIGNER — MVP 0.1

Open index.html in Chrome/Edge.

CURRENT MVP
- Upload PNG/JPG/SVG artwork.
- Enter known overall width and return depth.
- Select sign type / face / illumination.
- Choose or auto-recommend a SloanLED / FirstLite LED product.
- Auto-populate a silhouette with modules.
- Calculate module count, connected load and approximate 60 W driver quantity.
- Print the current production view to PDF.
- Export a BOM CSV.

IMPORTANT
This is an early engineering prototype, not yet a released production calculator.
The current raster population engine uses image thresholding and a safe-edge inset.
The next build should add true vector path parsing, row/path optimisation for narrow strokes,
separate face/halo algorithms, cable routing, voltage-drop checks, driver circuit grouping,
ribbon/reel routing, cross-section inputs, save/load projects, and a full supplier database.

Verified product examples incorporated:
- SloanLED Prism12 / Prism white product data and density principles.
- FirstLite FL Edge.
- FirstLite FL Vizion.
- FirstLite FL Prime sample data from supplier-published specifications.

Manufacturer product data remains authoritative and should be versioned in the production database.
