NE LED Population V0.2.1

FIX:
- Sign type, face/skin construction, and compatible LED drop-downs now initialize after DOMContentLoaded.
- Options are created with native DOM option elements for better Android/mobile browser compatibility.
- Native select rendering is explicitly preserved.
- Flex-face construction remains double-strike printed flex skin, not acrylic.
- LED pre-selection is filtered by sign type + internal depth + illumination + supplier.

DEPLOY:
Replace index.html and products.json in the GitHub repository with these files and commit to main.
Render should auto-deploy from main.
